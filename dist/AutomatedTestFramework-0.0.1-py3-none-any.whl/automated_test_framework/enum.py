#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :enum.py
# @Time      :2025/8/5 18:22
# @Author    :zhouxiaochuan
# @Description:
from enum import Enum


class AssertType(Enum):
    DATA_IN = "DATA_IN"
    LIST_EQUAL = "LIST_EQUAL"

