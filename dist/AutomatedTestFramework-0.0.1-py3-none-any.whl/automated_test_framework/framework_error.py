#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :framework_error.py
# @Time      :2025/8/3 22:02
# @Author    :zhouxiaochuan
# @Description: 

class NoParamError(Exception):
    """
    没有参数异常
    """
    pass
