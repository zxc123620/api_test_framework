#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :__init__.py.py
# @Time      :2025/8/3 22:50
# @Author    :zhouxiaochuan
# @Description:
import automated_test_framework.logger_config
import automated_test_framework.load_config
# load_config.init_config()


