#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :temp_data.py
# @Time      :2025/8/3 22:30
# @Author    :zhouxiaochuan
# @Description: 

class TempData:
    HEADER = {}
    TEMP_DATA = {}
