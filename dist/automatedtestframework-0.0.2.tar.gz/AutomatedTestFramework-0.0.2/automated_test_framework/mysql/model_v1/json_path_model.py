#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :json_path_model.py
# @Time      :2025-05-27 22:14
# @Author    :zhouxiaochuan
# @description:
from typing import Union

from pydantic import BaseModel

from automated_test_framework.mysql.model_v1.case_data_model import MysqlDataModel


class JsonPathDataModel(MysqlDataModel):
    class DataModel(BaseModel):
        expect_data: Union[dict, list, str]
        jsonpath_exp: str

        def get_list_expect_data(self):
            return list(self.expect_data)

    data: DataModel