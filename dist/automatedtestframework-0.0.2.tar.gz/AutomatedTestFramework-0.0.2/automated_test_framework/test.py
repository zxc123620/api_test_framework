#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :test.py
# @Time      :2025/10/27 23:44
# @Author    :zhouxiaochuan
# @Description:
from automated_test_framework.mysql.model_v2.url_save_model import UrlSaveModel

if __name__ == "__main__":
    print(UrlSaveModel.get(UrlSaveModel.key == "login"))