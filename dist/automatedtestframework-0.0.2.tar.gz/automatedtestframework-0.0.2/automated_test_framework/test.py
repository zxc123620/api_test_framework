#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Time:2025/10/20 21:07
# Author:zhouxiaochuan
# Description:
from automated_test_framework.mysql.model_v2.data_model import MysqlDataModel, MysqlJsonPathDataModel, MysqlJsonPathTimeRangeModel
from automated_test_framework.mysql.model_v2.page_locate_model import MysqlLocateDataModel
from automated_test_framework.mysql.model_v2.project_model import ProjectModel

if __name__ == '__main__':
    # print(MysqlDataModel.select().where(MysqlDataModel.key == "xlza.login.success"))
    print(MysqlJsonPathDataModel.select().where(MysqlJsonPathDataModel.key =="xlza.getMainPageStationList.validStationInfo4"))
    # print(MysqlJsonPathTimeRangeModel.select().where(MysqlJsonPathTimeRangeModel.key =="xlza.alarm.validAlarmRange"))
    a = MysqlJsonPathTimeRangeModel.get(MysqlJsonPathTimeRangeModel.key =="xlza.alarm.validAlarmRange")
    print(a.data.expect_data)
    print(a.data.expect_data.start_time)
    print(a.data.expect_data.end_time)
    b = MysqlLocateDataModel.get(MysqlLocateDataModel.key == "xlza.demod.test")
    print(b.key, b.locate_type, b.desc,b.locate_value, b.page )
    # print(item.data.expect_data)

    # print(ProjectModel.get(ProjectModel.id == 1))