#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :__init__.py.py
# @Time      :2025/8/3 22:50
# @Author    :zhouxiaochuan
# @Description:
from peewee import MySQLDatabase

import automated_test_framework.logger_config
import automated_test_framework.load_config
from automated_test_framework.meta_class import SingletonMeta


# from automated_test_framework.mysql.model_v1.time_range_model import JsonPathTimeRangeModel
# from automated_test_framework.mysql.model_v1.json_path_model import JsonPathDataModel
# from automated_test_framework.mysql.model_v1.case_data_model import MysqlDataModel
# load_config.init_config()

