#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @FileName  :test.py
# @Time      :2025/10/27 23:44
# @Author    :zhouxiaochuan
# @Description:
from automated_test_framework.mysql.model_v2.page_locate_model import MysqlLocateDataModel, MysqlLocateTypeModel

if __name__ == "__main__":
    # MysqlLocateTypeModel.get(MysqlLocateTypeModel.id == "CSS_SELECTOR")
    a = MysqlLocateDataModel.get(MysqlLocateDataModel.key == "login_btn")
    # print(a)
    print(a.locate_type.loc_type)
